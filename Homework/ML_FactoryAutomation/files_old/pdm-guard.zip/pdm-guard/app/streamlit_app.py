"""Streamlit 예측 웹앱: 센서값 입력 -> 고장 예측 -> DB 로깅 -> 이력 조회."""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import streamlit as st
from src import db, predict

st.set_page_config(page_title="설비 고장 예측 (PdM-Guard)", page_icon="🛠️", layout="wide")


@st.cache_resource
def _setup():
    engine = db.init_db()
    artifacts = predict.load_artifacts("xgb")
    return engine, artifacts


engine, artifacts = _setup()

st.title("🛠️ 설비 고장 예측 (PdM-Guard)")
st.caption("센서값을 입력하면 XGBoost 모델이 고장 확률을 예측합니다.")

with st.sidebar:
    st.header("센서 데이터 입력")
    type_ = st.selectbox("제품 등급 (Type)", ["L", "M", "H"], index=1)
    air = st.slider("공기 온도 [K]", 295.0, 305.0, 300.0, 0.1)
    proc = st.slider("공정 온도 [K]", 305.0, 314.0, 310.0, 0.1)
    rpm = st.slider("회전속도 [rpm]", 1160, 2890, 1500, 1)
    torque = st.slider("토크 [Nm]", 3.0, 77.0, 40.0, 0.1)
    wear = st.slider("공구 마모 [min]", 0, 260, 100, 1)
    go = st.button("고장 예측하기", type="primary")

col1, col2 = st.columns([1, 1])

if go:
    inp = {"type": type_, "air_temperature": air, "process_temperature": proc,
           "rotational_speed": rpm, "torque": torque, "tool_wear": wear}
    with db.get_session(engine) as s:
        res = predict.predict_and_log(inp, s, artifacts=artifacts)
    with col1:
        st.subheader("예측 결과")
        st.metric("고장 확률", f"{res['pred_proba']*100:.1f} %")
        if res["pred_label"] == 1:
            st.error("⚠️ 고장 위험: 점검 권장")
        else:
            st.success("✅ 정상 범위")

with col2:
    st.subheader("최근 예측 이력")
    try:
        with engine.connect() as conn:
            df = pd.read_sql(
                "SELECT prediction_id, pred_label, pred_proba, predicted_at "
                "FROM prediction ORDER BY prediction_id DESC LIMIT 10", conn)
        st.dataframe(df, use_container_width=True)
    except Exception as e:
        st.info(f"이력 없음: {e}")
