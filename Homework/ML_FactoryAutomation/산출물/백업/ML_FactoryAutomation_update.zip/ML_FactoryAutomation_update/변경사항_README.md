# 변경사항 요약 (Streamlit 업데이트)

이 zip은 직전 대화에서 **변경/신규 생성한 파일만** 담은 업데이트 패키지입니다.
기존 ML_FactoryAutomation 프로젝트에 아래 경로대로 덮어쓰면 됩니다.

## 포함 파일
| 경로 | 상태 | 설명 |
|---|---|---|
| app/streamlit_app.py | 변경(전체 교체) | 3탭 구조: ① 단건 예측 ② CSV 일괄검증 ③ 인터랙티브 학습(강사 Iris 패턴) |
| requirements.txt | 변경 | xgboost·sqlalchemy 포함, tensorflow-cpu는 주석(ML 제외) |
| 산출물/설비고장예측_Streamlit_시연방법_가이드_v2.docx | 변경(v2) | 공식 Streamlit 클라우드 매뉴얼 화면 순서 반영 + 3탭 시연 시나리오 |

## streamlit_app.py 핵심 변경점
- ③ 인터랙티브 학습 탭 신규: 사이드바 슬라이더(트리 개수/최대 깊이)로 실시간 재학습
  → 모델 정확도 + 특징 중요도(st.bar_chart). src.* 없이도 단독 동작.
- ①② 탭은 기존 모듈(src.predict/model_store/synth_ai4i) 있으면 자동 사용,
  없거나 시그니처가 다르면 joblib 직접 로드로 폴백(방어적).
- CSV 컬럼명이 표준(AI4I)과 달라도 후보 매핑으로 흡수.

## 주의 (원본 데이터 보존)
- 학습/예측 코드는 CSV를 메모리로 읽어 변환본(train_test_split·StandardScaler·get_dummies)을
  생성할 뿐, 원본 CSV 파일을 덮어쓰거나 inplace로 훼손하지 않습니다.
- 데이터 5/6은 물리룰로 '새로 생성'한 합성 파일이며 데이터 1(실데이터)을 수정한 것이 아닙니다.
